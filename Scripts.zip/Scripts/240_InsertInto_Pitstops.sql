select * from LapTimes

delete from LapTimes