﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Formula1MyLive.Interfaces
{
	public interface IValidatableConfiguration
	{
		void Validate();
	}
}
