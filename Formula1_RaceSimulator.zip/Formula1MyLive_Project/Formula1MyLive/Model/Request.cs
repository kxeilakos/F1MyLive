﻿using System;

namespace Formula1MyLive.Model
{
	public class Request
	{
		public Int16 Year { get; set; }
		public Int16 CircuitId { get; set; }
		public Int16 Lap { get; set; }
	}
}